<?php $attributes = $attributes->exceptProps(['title']); ?>
<?php foreach (array_filter((['title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="/css/app.css" rel="stylesheet">
        <title><?php echo e($title ?? 'Càritas @ Sant Josep Badalona'); ?></title>

        <script src="https://cdn.ckeditor.com/ckeditor5/26.0.0/classic/ckeditor.js"></script>
      </head>
    <body id="body" <?php echo e($attributes); ?>>
      <header class="border-b-2 border-red mb-20 pt-3 px-3">
        <div>
            <h1 class="text-h2 mb-5 text-center">Caritas Escritorio</h1>
            
                <div class="flex justify-between mx-72">
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="text-grey hover:text-red text-ui-main ml-3" type="submit">Desconectar</button>
                    </form>
                    <a href="<?php echo e(route('home')); ?>" class="text-grey hover:text-red text-ui-main">Página Principal</a>
                </div>
          
        </div>
    </header>
      <?php echo e($slot); ?>

     
    </body>
</html><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/backoffice-layout.blade.php ENDPATH**/ ?>