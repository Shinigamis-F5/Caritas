<h2 class="text-h3 flex text-center justify-center mb-6"><?php echo e(__('nav-quienes-somos')); ?></h2>
<div class="flex justify-center ">
 
    <img class="h-150px  md:h-450px rounded" src="<?php echo e(asset('storage/section/' . $aboutImg )); ?>" alt="Caritas Logo"/>
</div>
<p class="text-ui-tiny mx-6 my-4 normal-case">
    <?php if(app()->getLocale() == 'es'): ?> <?php echo html_entity_decode($aboutEs); ?>

    <?php else: ?> <?php echo html_entity_decode($aboutCat); ?>

    <?php endif; ?></p>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.anchor','data' => ['class' => 'mx-6 my-4','href' => '#','txt' => ''.e('santjosepbdn@gmail.com').'']]); ?>
<?php $component->withName('anchor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mx-6 my-4','href' => '#','txt' => ''.e('santjosepbdn@gmail.com').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/modals/who-we-are-component.blade.php ENDPATH**/ ?>