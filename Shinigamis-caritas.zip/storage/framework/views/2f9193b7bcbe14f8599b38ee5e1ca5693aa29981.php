        <a href="#"><h1 class="text-h1 text-right mr-6">x</h1></a>
        <div id="container" class="bg-white-dark text-center mx-4 text-mobile-main rounded-3xl">
            <h1 class="text-h1 m-4"> Donar</h1>
            <p class="my-4">
                Puedes hacer una donación por transferencia bancaria o con el número de Bizum:
                <br>
                <br>
                <?php echo e('Fiare. Banca Ética 
                ES05 – 1550 – 0001 – 2800 – 0193 – 5626'); ?>

                <?php echo e('codigo 33432'); ?>

            </p>
            <p  class="my-4">
                BENEFICIOS FISCALES
                <br>
                <br>
                Con tu aportación económica disfrutarás de beneficios fiscales que te permitirán desgravar los donativos en la Declaración de la Renta o Impuesto de Sociedades. Si quieres desgravar envianos al correo
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.anchor','data' => ['href' => 'mailto:santjosepbdn@gmail.com','txt' => 'santjosepbdn@mail.com']]); ?>
<?php $component->withName('anchor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => 'mailto:santjosepbdn@gmail.com','txt' => 'santjosepbdn@mail.com']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> con los siguientes datos: 
                <br>
                PARTICULAR: Nombre i Apellido / DNI / dirección postal
                EMPRESA 
                <br>
                ENTITAD: Razón social / CIF / dirección postal          

            </p>
            <div class="flex flex-col items-center border-2 border-red bg-donar bg-center bg-cover rounded-3xl my-10">
                <img class="relative left-20 bottom-16" src="<?php echo e(asset('storage/img/decoLogoIzq.png')); ?>" alt="">
                <p class="m-2">
                    con 10 € aportarás leche para una pareja durante un mes.
                </p>
                <img class="w-20 h-20 m-4" src="<?php echo e(asset('storage/img/milk.png')); ?>" alt="">
                <p class="m-2">
                    con 20 € tendrán también un plato de legumbres, pasta o arróz.
                </p>  
                <img class="w-20 h-20 m-4" src="<?php echo e(asset('storage/img/pasta.png')); ?>" alt="">
                <p class="m-2"> 
                    con 50 € podrán comprar pescado y carne para un mes 
                </p>
                <img class="w-32 h-32 m-4" src="<?php echo e(asset('storage/img/fish.png')); ?>" alt="">
                <p class="m-2">
                    amb més € hi afegiràs productes de neteja
                </p>
                <img class="w-20 h-20 m-6" src="<?php echo e(asset('storage/img/soap.svg')); ?>" alt="">
                <img class="relative right-24 top-10 w-24 z-2" src="<?php echo e(asset('storage/img/decoLogoDrch.png')); ?>" alt="">
            </div>
        </div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/modals/donation.blade.php ENDPATH**/ ?>