<?php $attributes = $attributes->exceptProps(['txt' => '', 'filename' => '', 'iAlt' => '']); ?>
<?php foreach (array_filter((['txt' => '', 'filename' => '', 'iAlt' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a <?php echo e($attributes->merge(['class' => 'inline-flex gap-2 items-start'])); ?>>
  <?php if($filename): ?>
    <img src="<?php echo e(asset('storage/img/' . $filename)); ?>" alt="<?php echo e($iAlt); ?>" class="w-5 h-5"/>
  <?php endif; ?>
  <?php echo e($txt); ?>

</a> <?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/anchor.blade.php ENDPATH**/ ?>