<h2 class="text-h3 flex text-center justify-center mb-6">QUE PUEDES HACER TU</h2>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => 'card1.jpg','titleCard' => 'Voluntario','button' => 'Voluntariado']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'card1.jpg','titleCard' => 'Voluntario','button' => 'Voluntariado']); ?>
  Todo el proyecto se realiza gracias a un equipo de voluntarios no remunerados que aportan su tiempo, ganas de ayudar y compromiso a favor de las familias vulnerables. Están organizados en diferentes grupos de trabajo definidos según las necesidades y sus aptitudes y disponibilidad.
  Los voluntarios están inscritos en el registro de Càritas y cuentan con un seguro, seguimiento, acreditación y formación.
  Si quieres ser voluntario envía un correo a caritasbdnsantjosep@gmail.com y nos pondremos en contacto contigo.
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => 'card2.jpg','titleCard' => 'Difusion','button' => 'Difundir']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'card2.jpg','titleCard' => 'Difusion','button' => 'Difundir']); ?>
  No pretendemos sólo recoger donativos, sino también hacer pedagogía del derecho a la alimentación y la dignidad de la persona. Este cambio de modelo que propone modificar las ayudas en especies para ayudas económicas supervisadas, va acompañado de una tarea de difusión, comunicación y sensibilización. Si quieres organizar alguna campaña, charla, taller en tu escuela, empresa, fundación ... envía un correo a caritasbdnsantjosep@gmail.com y nos pondremos en contacto contigo. 
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => 'card3.jpg','titleCard' => 'Colaborador','button' => 'Colaborar']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'card3.jpg','titleCard' => 'Colaborador','button' => 'Colaborar']); ?>Queremos trabajar en red, hacer barrio, ser comunidad: a través de la actividad comercial podemos mejorar las condiciones de vida de las personas desfavorecidas y promover un modelo económico más justo para todos. Si tienes un comercio de alimentación, productos de higiene o farmacia en Badalona, puedes colaborar ofreciendo descuentos a los usuarios de la tarjeta monedero, y pondremos tu logo en la web y material de difusión. 
  Envía un correo a caritasbdnsantjosep@gmail.com y nos pondremos en contacto contigo. 
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => 'card4.jpg','titleCard' => 'Donar','button' => 'Donar']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'card4.jpg','titleCard' => 'Donar','button' => 'Donar']); ?>Con tu donativo cargarás la tarjeta monedero para que las familias en situación de vulnerabildad puedan comprarse alimentos y productos de higiene y farmacia.
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/modals/what-u-can-do.blade.php ENDPATH**/ ?>