<h2 class="text-h3 lg:text-h2 flex text-center justify-center mb-6"><?php echo e(__('nav-que-puedes-hacer-tu')); ?></h2>
    <div class="flex justify-center text-body lg:text-d-body">
     
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => ''.e($volunteerImg).'','titleCard' => ''.e(__('volunteer-title-card')).'','button' => 'Voluntariado']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => ''.e($volunteerImg).'','titleCard' => ''.e(__('volunteer-title-card')).'','button' => 'Voluntariado']); ?>
        <?php if(app()->getLocale() == 'es' ): ?>  <?php echo html_entity_decode($volunteerEs); ?>

        <?php else: ?>  <?php echo html_entity_decode($volunteerCat); ?>

        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('volunteer-btn')).'','url' => 'mailto:santjosepbdn@gmail.com','normalUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('volunteer-btn')).'','url' => 'mailto:santjosepbdn@gmail.com','normal-url' => true]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => ''.e($explainTheProjectImg).'','titleCard' => ''.e(__('explain-the-project-title-card')).'','button' => 'Difundir']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => ''.e($explainTheProjectImg).'','titleCard' => ''.e(__('explain-the-project-title-card')).'','button' => 'Difundir']); ?>
        <?php if(app()->getLocale() == 'es'): ?>  <?php echo html_entity_decode($explainTheProjectEs); ?>

        <?php else: ?>  <?php echo html_entity_decode($explainTheProjectCat); ?>

        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('explain-the-project-btn')).'','url' => 'mailto:santjosepbdn@gmail.com','normalUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('explain-the-project-btn')).'','url' => 'mailto:santjosepbdn@gmail.com','normal-url' => true]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
      
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => ''.e($partnerImg).'','titleCard' => ''.e(__('partner-title-card')).'','button' => 'Colaborar']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => ''.e($partnerImg).'','titleCard' => ''.e(__('partner-title-card')).'','button' => 'Colaborar']); ?>
        <?php if(app()->getLocale() == 'es'): ?>  <?php echo html_entity_decode( $partnerEs); ?>

        <?php else: ?>  <?php echo html_entity_decode($partnerCat); ?>

        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('partner-btn')).'','url' => 'mailto:santjosepbdn@gmail.com','normalUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('partner-btn')).'','url' => 'mailto:santjosepbdn@gmail.com','normal-url' => true]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
       
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cards','data' => ['filename' => ''.e($donateImg).'','titleCard' => 'Donar','button' => 'Donar']]); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => ''.e($donateImg).'','titleCard' => 'Donar','button' => 'Donar']); ?>
        <?php if(app()->getLocale() == 'es'): ?>  <?php echo html_entity_decode($donateEs); ?>

        <?php else: ?>  <?php echo html_entity_decode($donateCat); ?>

        <?php endif; ?>
    
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('donation-title')).'','normalModal' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('donation-title')).'','normal-modal' => true]); ?><?php if (isset($component)) { $__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\DonationComponent::class, []); ?>
<?php $component->withName('modals.donation-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822)): ?>
<?php $component = $__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822; ?>
<?php unset($__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
       <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/modals/what-can-you-do-component.blade.php ENDPATH**/ ?>