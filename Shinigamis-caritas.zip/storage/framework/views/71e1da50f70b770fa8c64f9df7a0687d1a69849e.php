<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="/css/app.css" rel="stylesheet">
        <title>Caritas Badalona</title>
    </head>
    <body class="antialiased">
        <div>
            <?php if(Route::has('login')): ?>
                <div>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div>
            <a href="<?php echo e(route('language', 'es')); ?>">Castellano</a>
            <a href="<?php echo e(route('language', 'cat')); ?>">Catalan</a>
            <h2>
                <?php echo e(__('test')); ?>

            </h2>
        </div>
    </body>
</html>
<?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/welcome.blade.php ENDPATH**/ ?>