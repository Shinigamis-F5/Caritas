<div id="hero" class="bg-hero bg-cover bg-center flex flex-col py-16 place-items-center mt-24 lg:place-content-center lg:h-540px lg:gap-16">
    <div id="heroText" class="px-6 py-20 text-white text-center lg:flex lg:flex-col lg:max-w-7xl lg:gap-8">
        <h1 class="text-h1 font-black lg:text-d-h1"><?php echo e(__('hero-titulo')); ?></h1>
        <p class="lg:text-d-body"><?php echo e(__('hero-texto')); ?></p>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('hero-boton')).'','normalModal' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('hero-boton')).'','normal-modal' => true]); ?><?php if (isset($component)) { $__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\DonationComponent::class, []); ?>
<?php $component->withName('modals.donation-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822)): ?>
<?php $component = $__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822; ?>
<?php unset($__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/hero.blade.php ENDPATH**/ ?>