<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backoffice-layout','data' => []]); ?>
<?php $component->withName('backoffice-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <main class="pl-5 flex gap-20 flex-wrap justify-center text-body m-4">
        <div class="flex flex-col gap-20 flex-grow-1 w-1/3">
            <section class="border-red border-2 rounded-2xl p-5 h-64 flex-grow-0">
                <div class="flex justify-between mb-10">
                    <h2 class="text-h3">Datos de conexión</h2>
                    <a href="<?php echo e(route('user-profile-information.edit')); ?>" class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light flex-end">Editar</a>
                </div>
                <div>
                    <div class="">
                        <h4 class="font-bold mb-3">Nombre:
                            <span class="font-normal">
                                <?php echo e($user->name); ?>

                            </span>
                        </h4>
                    </div>
                    <div class="pt-2">
                        <h4 class="font-bold mb-3">E-mail:
                            <span class="font-normal">
                                <?php echo e($user->email); ?>

                            </span>
                        </h4>
                    </div>
                </div>

            </section>

            <section class="border-red border-2 rounded-2xl p-5 flex-grow-0">
                <?php if($profile): ?>
                <div class="flex justify-between mb-10">
                    <h2 class="text-h3">Logotipo</h2>
                    <?php if(!$profile->logo): ?>
                    <a href="<?php echo e(route('logo.edit', $profile->id)); ?>" class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light flex-end">Subir</a>
                    <?php else: ?>
                    <form action="<?php echo e(route('logo.delete', $profile->id)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backoffice-button','data' => ['txt' => 'Borrar']]); ?>
<?php $component->withName('backoffice-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => 'Borrar']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </form>
                    <?php endif; ?>
                </div>

                <div class="object-contain">
                    <img class="w-32 h-32" src="
                    <?php if($profile->logo): ?>
                        <?php echo e(asset('storage/logo/' . $profile->logo)); ?>

                    <?php else: ?>
                        <?php echo e(asset('storage/logo/placeholder-300x202.jpg')); ?>

                    <?php endif; ?>
                    " alt="Logotipo">
                </div>

                <?php else: ?>
                <div class="flex justify-between mb-10">
                    <h2>Para poder subir el logotipo necesitais crear el perfil de la organización</h2>
                </div>
                <?php endif; ?>
            </section>

            <?php if(!$profile): ?>
            <section class=" border-red border-2 rounded-2xl p-5 flex justify-between ">
                <h3 class="text-h3">Crear perfil de la organización</h3>
                <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light" href="<?php echo e(route('dashboard.create')); ?>" type="button">
                    Crear
                </a>

            </section>
            <?php else: ?>
            <section class=" border-red border-2 rounded-2xl p-5 relative flex-grow-1">
                <h2 class="text-h3">Perfil de la organización</h2>
                <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light absolute top-5 right-5 text-center" href="<?php echo e(route('dashboard.edit', $profile->id)); ?>" type="button">
                    Editar
                </a>
                <div class="pt-10 object-contain">
                    <h4 class="font-bold mb-3">Nombre:
                        <span class="font-normal">
                            <?php echo e($profile->name); ?>

                        </span>
                    </h4>
                    <h4 class="font-bold mb-3">Email:
                        <span class="font-normal">
                            <?php echo e($profile->org_email); ?>

                        </span>
                    </h4>
                    <h4 class="font-bold mb-3">Dirección:
                        <span class="font-normal">
                            <?php echo e($profile->direction); ?>

                        </span>
                    </h4>
                    <h4 class="font-bold mb-3">Población:
                        <span class="font-normal">
                            <?php echo e($profile->city); ?>

                        </span>
                    </h4>
                    <h4 class="font-bold mb-3">Código Postal:
                        <span class="font-normal">
                            <?php echo e($profile->postcode); ?>

                        </span>
                    </h4>
                    <h4 class="font-bold mb-3">Teléfono:
                        <span class="font-normal">
                            <?php echo e($profile->phone); ?>

                        </span>
                    </h4>
                    <h2 class="text-h3 my-6">
                        Datos Bancarios:
                    </h2>
                    <h4 class="font-bold mb-3">IBAN:
                        <span class="font-normal">
                            <?php echo e($profile->bankAccount); ?>

                        </span>
                    </h4>
                    <h4 class="font-bold "> Bizum:
                        <span class="font-normal">
                            <?php echo e($profile->bizum); ?>

                        </span>
                    </h4>

                </div>
            </section>
            <?php endif; ?>


        </div>
        <div class="w-1/3">
            <section class="w-full border-red border-2 rounded-2xl p-5 mb-20 flex flex-col items-center">
                <h3 class="text-h3 text-center my-6">
                    Qui Som / <br>
                    Quiénes Somos
                </h3>
                <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light text-center w-2/3 " href="<?php echo e(route('about')); ?>" type="button">
                    Qui Som / Quienes Somos
                </a>

            </section>
            <section class="w-full flex flex-col border-red border-2 rounded-2xl p-5 mb-20 justify-between gap-10 items-center">
                <h3 class="text-h3 text-center my-6">
                    Que Pots Fer Tu / <br>
                    Que Puedes Hacer Tu
                </h3>

                <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light text-center w-2/3" href="<?php echo e(route('donate')); ?>" type="button">
                    Donar / Donar
                </a>
                <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light text-center w-2/3" href="<?php echo e(route('explainTheProject')); ?>" type="button">
                    Difusió / Difusión
                    <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light text-center w-2/3" href="<?php echo e(route('volunteer')); ?>" type="button">
                        Voluntari/ Voluntario
                    </a>
                    <a class="block bg-red hover:bg-red-lighter text-white font-bold p-2 text-md rounded border-b-4 border-red-light text-center w-2/3" href="<?php echo e(route('partner')); ?>" type="button">
                        Col·laborador / Colaborador
                    </a>
            </section>
        </div>
    </main>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/Backoffice/dashboard.blade.php ENDPATH**/ ?>