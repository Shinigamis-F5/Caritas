<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav','data' => []]); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.back-to-top','data' => []]); ?>
<?php $component->withName('back-to-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <main class="flex flex-col items-center gap-48">
        <section class="w-full" >
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.hero','data' => []]); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.iframe','data' => ['src' => 'https://www.youtube.com/embed/FiMvPqisUCU','class' => 'w-full h-72 lg:h-450px']]); ?>
<?php $component->withName('iframe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => 'https://www.youtube.com/embed/FiMvPqisUCU','class' => 'w-full h-72 lg:h-450px']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </section>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.separator','data' => []]); ?>
<?php $component->withName('separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <section class="flex flex-row items-center my-10 mx-6 justify-between w-full">
            <img class="hidden rounded-r-imglateral md:flex md:h-350px md:w-48 lg:h-365px lg:w-80" src="<?php echo e(asset('storage/img/SectionOneLeft.jpg')); ?>" alt="Side banner" />
            <div class="flex flex-col gap-12 mx-6 w-660px">
                <h2 class="text-h2 p-3 text-center font-black md:text-d-h3 md:p-0"><?php echo e(__('necesidades-basicas-titulo')); ?></h2>
                <p class="inline-flex flex-col gap-8 max-w-5xl">
                    <span>
                        <b><?php echo e(__('necesidades-basicas-paragrafo1-destacado1')); ?></b> <?php echo e(__('necesidades-basicas-paragrafo1')); ?>

                    </span>
                    <span>
                        <?php echo e(__('necesidades-basicas-paragrafo2')); ?> <b><?php echo e(__('necesidades-basicas-paragrafo2-destacado1')); ?></b>
                    </span>
                    <span>
                        <?php echo e(__('necesidades-basicas-paragrafo3-parte1')); ?> <b><?php echo e(__('necesidades-basicas-paragrafo3-destacado1')); ?></b>, <?php echo e(__('necesidades-basicas-paragrafo3-parte2')); ?> <b><?php echo e(__('necesidades-basicas-paragrafo3-destacado2')); ?></b>.<?php echo e(__('necesidades-basicas-paragrafo3-parte3')); ?>

                    </span>
                    <span>
                        <b><?php echo e(__('necesidades-basicas-paragrafo4-destacado1')); ?></b>, <?php echo e(__('necesidades-basicas-paragrafo4')); ?>

                    </span>
                </p>
            </div>
            <img class="hidden rounded-l-imglateral md:flex md:h-350px md:w-48 lg:h-365px lg:w-80" src="<?php echo e(asset('storage/img/sectionOneRight.jpg')); ?>" alt="Side banner" />
        </section>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.separator','data' => []]); ?>
<?php $component->withName('separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <section class="flex flex-col items-center gap-20 mx-6 lg:gap-60">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mini-hero','data' => ['filename' => 'family.svg','alt' => '','class' => 'gap-4']]); ?>
<?php $component->withName('mini-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'family.svg','alt' => '','class' => 'gap-4']); ?>
                <h2 class="text-h2 text-center font-bold max-w-7xl md:text-d-h3"><?php echo e(__('necesidades-familias-titulo')); ?></h2>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <div class="flex flex-col gap-24 lg:flex-row lg:flex-wrap lg:justify-around">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.downtick-list','data' => ['title' => ''.e(__('necesidades-familias-seccion1-trabajo')).'']]); ?>
<?php $component->withName('downtick-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('necesidades-familias-seccion1-trabajo')).'']); ?>
                    <li><?php echo e(__('necesidades-familias-seccion1-punto1')); ?></li>
                    <li><?php echo e(__('necesidades-familias-seccion1-punto2')); ?></li>
                    <li><?php echo e(__('necesidades-familias-seccion1-punto3')); ?></li>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.downtick-list','data' => ['title' => ''.e(__('necesidades-familias-seccion2-titulo')).'']]); ?>
<?php $component->withName('downtick-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('necesidades-familias-seccion2-titulo')).'']); ?>
                    <li><?php echo e(__('necesidades-familias-seccion2-punto1')); ?></li>
                    <li><?php echo e(__('necesidades-familias-seccion2-punto2')); ?></li>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.downtick-list','data' => ['title' => ''.e(__('necesidades-familias-seccion3-titulo')).'','class' => 'w-full']]); ?>
<?php $component->withName('downtick-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('necesidades-familias-seccion3-titulo')).'','class' => 'w-full']); ?>
                    <li><?php echo e(__('necesidades-familias-seccion3-punto1')); ?></li>
                    <li><?php echo e(__('necesidades-familias-seccion3-punto2')); ?></li>
                    <li><?php echo e(__('necesidades-familias-seccion3-punto3')); ?></li>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mini-hero','data' => ['filename' => 'giving.svg','alt' => '','class' => 'lg:flex-row-reverse']]); ?>
<?php $component->withName('mini-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'giving.svg','alt' => '','class' => 'lg:flex-row-reverse']); ?>
                    <h2 class="text-h2 p-3 text-center items-center font-bold max-w-7xl md:text-d-h3"><?php echo e(__('modelo-antiguo-titulo')); ?></h2>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <ul class="font-bold text-body gap-12 md:grid md:grid-cols-2 md:grid-rows-2 md:text-d-body md:w-full md:place-items-center">
                    <li class="md:w-350px"><?php echo e(__('modelo-antiguo-punto1')); ?></li>
                    <li class="md:w-350px"><?php echo e(__('modelo-antiguo-punto2')); ?></li>
                    <li class="md:w-350px"><?php echo e(__('modelo-antiguo-punto3')); ?></li> 
                    <li class="md:w-350px"><?php echo e(__('modelo-antiguo-punto4')); ?></li>
            </ul>
        </section>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.separator','data' => []]); ?>
<?php $component->withName('separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <section class="flex flex-col mx-6 gap-40">
        <h2 class="text-h2 text-center p-3 font-bold max-w-7xl place-self-center md:text-d-h3"><?php echo e(__('nuestro-modelo-titulo')); ?></h2>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mini-hero','data' => ['filename' => 'innovation.svg','alt' => '','class' => 'lg:flex-row-reverse']]); ?>
<?php $component->withName('mini-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'innovation.svg','alt' => '','class' => 'lg:flex-row-reverse']); ?>
                <ul class="font-bold gap-12">
                    <li><?php echo e(__('nuestro-modelo-punto1')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto2')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto3')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto4')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto5')); ?></li>
                </ul>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.mini-hero','data' => ['filename' => 'bestof.svg','alt' => '','class' => 'gap-20']]); ?>
<?php $component->withName('mini-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['filename' => 'bestof.svg','alt' => '','class' => 'gap-20']); ?>
                <ul class="font-bold gap-12">
                    <li><?php echo e(__('nuestro-modelo-punto6')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto7')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto8')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto9')); ?></li>
                    <li><?php echo e(__('nuestro-modelo-punto10')); ?></li>
                </ul>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </section>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.separator','data' => []]); ?>
<?php $component->withName('separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <section class="flex flex-col md:flex-row justify-around w-full mx-3 px-3 max-w-screen-xl">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.iframe','data' => ['src' => 'https://www.youtube.com/embed/sVGOeoHe8hQ','class' => 'lg:h-80 xl:w-375px xl:h-350px']]); ?>
<?php $component->withName('iframe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => 'https://www.youtube.com/embed/sVGOeoHe8hQ','class' => 'lg:h-80 xl:w-375px xl:h-350px']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.iframe','data' => ['src' => 'https://www.youtube.com/embed/XHnDWb9FzAM','class' => 'lg:h-80 xl:w-375px xl:h-350px']]); ?>
<?php $component->withName('iframe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => 'https://www.youtube.com/embed/XHnDWb9FzAM','class' => 'lg:h-80 xl:w-375px xl:h-350px']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.iframe','data' => ['src' => 'https://www.youtube.com/embed/sHxuuPIcwbo','class' => 'lg:h-80 xl:w-375px xl:h-350px']]); ?>
<?php $component->withName('iframe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => 'https://www.youtube.com/embed/sHxuuPIcwbo','class' => 'lg:h-80 xl:w-375px xl:h-350px']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </section>
        <section class="text-center flex flex-col items-center mx-6 gap-20">
            <div class="flex flex-col gap-8">
                <p class="text-h5 font-black md:text-d-h5"><?php echo e(__('seccion-videos-subtitulo')); ?></p>
                <h2 class="text-h2 font-black max-w-980px md:text-d-h3"><?php echo e(__('seccion-videos-titulo')); ?></h2>
            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('hero-boton')).'','normalModal' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('hero-boton')).'','normal-modal' => true]); ?><?php if (isset($component)) { $__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\DonationComponent::class, []); ?>
<?php $component->withName('Modals.donation-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822)): ?>
<?php $component = $__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822; ?>
<?php unset($__componentOriginal9442d7ef2ec7d372f8e84b5f432206288709f822); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </section>
    </main>
        <?php if (isset($component)) { $__componentOriginal06916d44330b660d207d7b317748ea85e924b054 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FooterComponent::class, []); ?>
<?php $component->withName('footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-20']); ?>
<?php if (isset($__componentOriginal06916d44330b660d207d7b317748ea85e924b054)): ?>
<?php $component = $__componentOriginal06916d44330b660d207d7b317748ea85e924b054; ?>
<?php unset($__componentOriginal06916d44330b660d207d7b317748ea85e924b054); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/landing.blade.php ENDPATH**/ ?>