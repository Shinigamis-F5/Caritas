<div>
    <img src="<?php echo e(asset('storage/img/burgerMenu.png')); ?>" alt="Menu"/>
</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/burguerMenu.blade.php ENDPATH**/ ?>