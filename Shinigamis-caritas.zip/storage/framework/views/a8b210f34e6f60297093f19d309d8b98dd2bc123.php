<?php $attributes = $attributes->exceptProps(['txt', 'url', 'normal' => '', 'nav' => '', 'normalModal' => '', 'navModal' => '', 'normalUrl' => '', 'navUrl' => '', 'burguer' => '', 'burguerBtn' => '',
'burguerUrl' => '']); ?>
<?php foreach (array_filter((['txt', 'url', 'normal' => '', 'nav' => '', 'normalModal' => '', 'navModal' => '', 'normalUrl' => '', 'navUrl' => '', 'burguer' => '', 'burguerBtn' => '',
'burguerUrl' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($normal): ?>
    <button class="btn"><?php echo e($txt); ?></button>
<?php endif; ?>

<?php if($nav): ?>
    <button class="nav__btn"><?php echo e($txt); ?></button>
<?php endif; ?>

<?php if($normalUrl): ?>
    <a role="button" href="<?php echo e($url); ?>"><button class="btn btn-space"><?php echo e($txt); ?></button></a>
<?php endif; ?>

<?php if($navUrl): ?>
    <a role="button" href="<?php echo e($url); ?>"><button class="nav__btn w-full h-full"><?php echo e($txt); ?></button></a>
<?php endif; ?>

<?php if($normalModal): ?>
<div x-data="{ open: false }" class="btn">
    <button @click="open = true" class="btn-space"><?php echo e($txt); ?></button>
    <div class="modal__overlay" x-show="open">
      <button @click="open = false" class="modal__close">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="modal__close-svg">
            <path d="M24 4.365L19.635 0L12 7.635L4.365 0L0 4.365L7.635 12L0 19.635L4.365 24L12 16.365L19.635 24L24 19.635L16.365 12L24 4.365Z" fill="black"/>
          </svg>
      </button>
      <div class="modal__dialog" @click.away="open = false">
        <?php echo e($slot); ?>

      </div>
    </div>
</div>
<?php endif; ?>

<?php if($navModal): ?>
<div x-data="{ open: false }" class="nav__btn">
    <button @click="open = true" class="w-full h-full"><?php echo e($txt); ?></button>
    <div class="modal__overlay" x-show="open">
      <button @click="open = false" class="modal__close">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="modal__close-svg">
            <path d="M24 4.365L19.635 0L12 7.635L4.365 0L0 4.365L7.635 12L0 19.635L4.365 24L12 16.365L19.635 24L24 19.635L16.365 12L24 4.365Z" fill="black"/>
          </svg>
      </button>
      <div class="modal__dialog" @click.away="open = false">
        <?php echo e($slot); ?>

      </div>
    </div>
</div>
<?php endif; ?>

<?php if($burguerBtn): ?>
<div x-data="{ show: false }" class="text-left">
    <button @click="show = true" class="text-ui-main font-bold uppercase w-full h-full text-left"><?php echo e($txt); ?></button>
    <div class="modal__overlay" x-show="show">
      <button @click="show = false" class="modal__close">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="modal__close-svg">
            <path d="M24 4.365L19.635 0L12 7.635L4.365 0L0 4.365L7.635 12L0 19.635L4.365 24L12 16.365L19.635 24L24 19.635L16.365 12L24 4.365Z" fill="black"/>
          </svg>
      </button>
      <div class="modal__dialog" @click.away="show = false">
        <?php echo e($slot); ?>

      </div>
    </div>
</div>
<?php endif; ?>

<?php if($burguerUrl): ?>
    <a role="button" href="<?php echo e($url); ?>"><button class="text-ui-main font-bold uppercase w-full h-full text-left"><?php echo e($txt); ?></button></a>
<?php endif; ?><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/button.blade.php ENDPATH**/ ?>