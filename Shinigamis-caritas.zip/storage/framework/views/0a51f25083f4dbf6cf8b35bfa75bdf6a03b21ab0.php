<?php $attributes = $attributes->exceptProps(['title']); ?>
<?php foreach (array_filter((['title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'flex flex-col items-center gap-8'])); ?>>
  <p class="text-white rounded-t-dtl w-full bg-gradient-to-b from-red-gd to-red-gd2 text-center font-bold text-ui-main uppercase py-4 md:text-d-ui-main md:w-375px"><?php echo e($title); ?></p>
  <ul class="font-bold md:gap-2">
    <?php echo e($slot); ?>

  </ul>
</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/downtick-list.blade.php ENDPATH**/ ?>