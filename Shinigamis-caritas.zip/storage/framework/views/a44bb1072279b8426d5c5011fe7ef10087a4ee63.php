<?php $attributes = $attributes->exceptProps(['filename', 'alt', 'reverse' => 'false']); ?>
<?php foreach (array_filter((['filename', 'alt', 'reverse' => 'false']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'flex flex-col items-center lg:flex-row'])); ?>>
    <img src="<?php echo e(asset('storage/img/' . $filename)); ?>" alt="<?php echo e($alt); ?>" class="w-150px h-150px md:w-350px md:h-350px">
    <?php echo e($slot); ?>

</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/mini-hero.blade.php ENDPATH**/ ?>