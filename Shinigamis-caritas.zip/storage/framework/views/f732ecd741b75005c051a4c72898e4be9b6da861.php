<a href="#"><h1 class="text-h1 text-right mr-6">x</h1></a>
<div id="container" class="bg-white-dark text-black text-center mx-4 text-body lg:text-d-main rounded-3xl">
    <h1 class="text-h1 m-4"> <?php echo e(__('donation-title')); ?></h1>
    <p class="my-4 text-ui-main lg:text-d-ui-main">
        <?php echo e(__('donation-account')); ?> <br>
    </p>
    <h4 class="text-ui-main lg:text-d-ui-main">
        <?php echo e($profile->bankAccount); ?> <br>
    </h4>
    <p>
        <?php echo e(__('donation-bizum')); ?><br>
    </p>
    <h4 class="text-ui-main lg:text-d-ui-main">
        <?php echo e($profile->bizum); ?>

    </h4>

    <h2 class="text-h4 lg:text-d-h4 mt-9"><?php echo e(__('donation-tax-relief-title')); ?></h2>
    <p  class="mb-4">
        <br>
        <br>
        <?php echo e(__('donation-tax-relief-text')); ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.anchor','data' => ['href' => 'mailto:santjosepbdn@gmail.com','txt' => 'santjosepbdn@mail.com']]); ?>
<?php $component->withName('anchor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => 'mailto:santjosepbdn@gmail.com','txt' => 'santjosepbdn@mail.com']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php echo e(__('donation-tax-relief-text-2')); ?> 
        <br>
        <?php echo e(__('donation-tax-relief-data')); ?>

        <br>
        <?php echo e(__('donation-tax-relief-data-entidad')); ?>         

    </p>
    <div class="flex flex-col items-center border-2 border-red bg-donar bg-center bg-cover rounded-3xl my-10">
       
        <p class="m-2">
            <?php echo e(__('donation-10')); ?>

        </p>
        <img class="w-20 h-20 m-4" src="<?php echo e(asset('storage/img/milk.png')); ?>" alt="">
        <p class="m-2">
            <?php echo e(__('donation-20')); ?>

        </p>  
        <img class="w-20 h-20 m-4" src="<?php echo e(asset('storage/img/pasta.png')); ?>" alt="">
        <p class="m-2"> 
             <?php echo e(__('donation-50')); ?>

        </p>
        <img class="w-32 h-32 m-4" src="<?php echo e(asset('storage/img/fish.png')); ?>" alt="">
        <p class="m-2">
            <?php echo e(__('donation-+50')); ?>

        </p>
        <img class="w-20 h-20 m-6" src="<?php echo e(asset('storage/img/soap.svg')); ?>" alt="">
    </div>
</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/modals/donation-component.blade.php ENDPATH**/ ?>