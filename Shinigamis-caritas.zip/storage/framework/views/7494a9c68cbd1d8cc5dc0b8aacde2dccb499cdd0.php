<nav id="navBox" class="nav">
<?php if(app()->getLocale() == 'es'): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-idioma-catalan')).'','url' => ''.e(route('language', 'cat')).'','navUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-idioma-catalan')).'','url' => ''.e(route('language', 'cat')).'','nav-url' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php else: ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-idioma-castellano')).'','url' => ''.e(route('language', 'es')).'','navUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-idioma-castellano')).'','url' => ''.e(route('language', 'es')).'','nav-url' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-quienes-somos')).'','navModal' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-quienes-somos')).'','nav-modal' => true]); ?><?php if (isset($component)) { $__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\WhoWeAreComponent::class, []); ?>
<?php $component->withName('Modals.who-we-are-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9)): ?>
<?php $component = $__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9; ?>
<?php unset($__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal1ca428504288805715963490a5fd7765b16e3200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LogoComponent::class, []); ?>
<?php $component->withName('logo-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => 'https://www.santjosepbadalona.cat/','class' => 'nav__logo']); ?>
<?php if (isset($__componentOriginal1ca428504288805715963490a5fd7765b16e3200)): ?>
<?php $component = $__componentOriginal1ca428504288805715963490a5fd7765b16e3200; ?>
<?php unset($__componentOriginal1ca428504288805715963490a5fd7765b16e3200); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-que-puedes-hacer-tu')).'','navModal' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-que-puedes-hacer-tu')).'','nav-modal' => true]); ?><?php if (isset($component)) { $__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\WhatCanYouDoComponent::class, []); ?>
<?php $component->withName('Modals.what-can-you-do-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe)): ?>
<?php $component = $__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe; ?>
<?php unset($__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-contacto')).'','navModal' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-contacto')).'','nav-modal' => true]); ?><?php if (isset($component)) { $__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\ContactComponent::class, []); ?>
<?php $component->withName('Modals.contact-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3)): ?>
<?php $component = $__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3; ?>
<?php unset($__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.burguer-menu','data' => []]); ?>
<?php $component->withName('burguer-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</nav>

<?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5-Bootcamp\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/nav.blade.php ENDPATH**/ ?>