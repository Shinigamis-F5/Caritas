<?php $attributes = $attributes->exceptProps(['href', 'txt', 'container']); ?>
<?php foreach (array_filter((['href', 'txt', 'container']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a href="<?php echo e($href ?? 'https://www.santjosepbadalona.cat/'); ?>" target="_blank" class="place-self-center <?php echo e($container ?? ''); ?>">
    <img src="<?php echo e(asset('storage/logo/' . $profile->logo)); ?>" alt="Logo" <?php echo e($attributes); ?> />
</a><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/logo-component.blade.php ENDPATH**/ ?>