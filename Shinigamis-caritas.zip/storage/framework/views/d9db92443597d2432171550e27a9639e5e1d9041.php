<div x-data="{ open: false }" class="h-24 absolute lg:hidden">
    <button @click="open = true">
        <svg width="64" height="60" viewBox="0 0 64 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M11 18H53" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M11 30H53" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M11 42H53" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>
        <div class="relative top-0 z-20 p-6 flex flex-col gap-3 rounded-lg uppercase bg-white shadow-2xl" @click.away="open = false" x-show="open">
        <?php if(app()->getLocale() == 'es'): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-idioma-catalan')).'','url' => ''.e(route('language', 'cat')).'','burguerUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-idioma-catalan')).'','url' => ''.e(route('language', 'cat')).'','burguer-url' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-idioma-castellano')).'','url' => ''.e(route('language', 'es')).'','burguerUrl' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-idioma-castellano')).'','url' => ''.e(route('language', 'es')).'','burguer-url' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-quienes-somos')).'','burguerBtn' => true,'@click' => 'open = false']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-quienes-somos')).'','burguer-btn' => true,'@click' => 'open = false']); ?><?php if (isset($component)) { $__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\WhoWeAreComponent::class, []); ?>
<?php $component->withName('modals.who-we-are-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9)): ?>
<?php $component = $__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9; ?>
<?php unset($__componentOriginal43318875b7f47616b6b8a6deb8584143d3dab8f9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-que-puedes-hacer-tu')).'','burguerBtn' => true,'@click' => 'open = false']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-que-puedes-hacer-tu')).'','burguer-btn' => true,'@click' => 'open = false']); ?><?php if (isset($component)) { $__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\WhatCanYouDoComponent::class, []); ?>
<?php $component->withName('modals.what-can-you-do-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe)): ?>
<?php $component = $__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe; ?>
<?php unset($__componentOriginalaab98dd778d8eb6544dce04211124cf0701f19fe); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['txt' => ''.e(__('nav-contacto')).'','burguerBtn' => true,'@click' => 'open = false']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['txt' => ''.e(__('nav-contacto')).'','burguer-btn' => true,'@click' => 'open = false']); ?><?php if (isset($component)) { $__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\ContactComponent::class, []); ?>
<?php $component->withName('modals.contact-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3)): ?>
<?php $component = $__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3; ?>
<?php unset($__componentOriginal91b3ee3108b55596929fdf729e047c99607e4fc3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/burguer-menu.blade.php ENDPATH**/ ?>