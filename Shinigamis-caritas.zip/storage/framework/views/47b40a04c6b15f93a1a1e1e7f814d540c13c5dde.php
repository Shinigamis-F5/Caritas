<?php $attributes = $attributes->exceptProps(['skinny' => '', 'traslucid' => '']); ?>
<?php foreach (array_filter((['skinny' => '', 'traslucid' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<hr class="w-2/4 lg:w-850px border-red shadow-hr self-center <?php echo e($skinny ? 'w-full' : 'border-4'); ?> <?php echo e($traslucid ? 'opacity-50' : ''); ?>"><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/separator.blade.php ENDPATH**/ ?>