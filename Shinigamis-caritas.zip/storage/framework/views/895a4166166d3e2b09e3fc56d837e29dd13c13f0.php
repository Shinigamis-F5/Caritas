<?php echo e($slot); ?>

<?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>