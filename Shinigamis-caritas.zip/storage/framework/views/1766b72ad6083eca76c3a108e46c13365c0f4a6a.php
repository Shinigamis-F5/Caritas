<?php $attributes = $attributes->exceptProps(['titleCard', 'filename', 'button']); ?>
<?php foreach (array_filter((['titleCard', 'filename', 'button']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
​
​
<div class="flex flex-row w-11/12 my-5 border-grey-light border p-2 rounded gap-10">
  <div class="w-2/4 ">
    <img class="hidden lg:flex w-full h-full object-cover p-2" src="<?php echo e(asset('storage/section/' . $filename)); ?>" alt="">
  </div>  
    <div class="flex flex-col normal-case">
      <h5 class="font-sans text-h3 lg:text-d-h4"><?php echo e($titleCard); ?></h5>
      <?php echo e($slot); ?>

      
    </div>
</div><?php /**PATH E:\Giacomo\Xamp-sites\FactoriaF5\ProyectosEnEquipo\Shinigami\Shinigamis-caritas\resources\views/components/cards.blade.php ENDPATH**/ ?>